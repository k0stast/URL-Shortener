package com.example;

import redis.clients.jedis.Jedis;
import java.util.Scanner;
import java.util.Random;

public class UrlShortener {
    private static Jedis jedis = new Jedis("redis-shortener", 6379); // host = όνομα container
    private static Scanner scanner = new Scanner(System.in);
    private static String username;

    public static void main(String[] args) {
        System.out.print("Enter your username: ");
        username = scanner.nextLine();

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Insert new URL");
            System.out.println("2. Query short URL");
            System.out.println("3. View statistics");
            System.out.println("4. Exit");

            System.out.print("Your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    handleInsertion();
                    break;
                case "2":
                    handleQuery();
                    break;
                case "3":
                    handleStatistics();
                    break;
                case "4":
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // ========== INSERTION ==========
    private static void handleInsertion() {
        System.out.print("Enter long URL: ");
        String longUrl = scanner.nextLine();

        // Αν υπάρχει ήδη
        if (jedis.hexists("url:long", longUrl)) {
            String existingShort = jedis.hget("url:long", longUrl);
            System.out.println("This URL already exists! Short URL: " + existingShort);
            return;
        }

        // Δημιουργία νέου short URL
        String shortCode = generateShortCode();

        // Αποθήκευση
        jedis.hset("url:long", longUrl, shortCode);
        jedis.hset("url:short", shortCode, longUrl);
        jedis.sadd("user:" + username, shortCode);
        jedis.hincrBy("user:count", username, 1);
        jedis.set("counter:" + shortCode, "0");

        System.out.println("Short URL created: " + shortCode);
    }

    // ========== QUERY ==========
    private static void handleQuery() {
        System.out.print("Enter short URL: ");
        String shortCode = scanner.nextLine();

        if (jedis.hexists("url:short", shortCode)) {
            String longUrl = jedis.hget("url:short", shortCode);
            jedis.incr("counter:" + shortCode);
            System.out.println("Original URL: " + longUrl);
        } else {
            System.out.println("Short URL not found.");
        }
    }

    // ========== STATISTICS ==========
    private static void handleStatistics() {
        // Πλήθος εισαγωγών χρήστη
        String count = jedis.hget("user:count", username);
        if (count == null)
            count = "0";
        System.out.println("Your total insertions: " + count);

        // Υπολογισμός μέσου όρου αιτήσεων
        var keys = jedis.hkeys("url:short");
        int total = 0;
        int num = 0;
        for (String shortCode : keys) {
            String val = jedis.get("counter:" + shortCode);
            total += val == null ? 0 : Integer.parseInt(val);
            num++;
        }
        double average = num == 0 ? 0.0 : (double) total / num;
        System.out.println("Average query count for all short URLs: " + average);
    }

    // ========== RANDOM STRING ==========
    private static String generateShortCode() {
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random rand = new Random();
        StringBuilder sb = new StringBuilder(6);
        for (int i = 0; i < 6; i++) {
            sb.append(chars.charAt(rand.nextInt(chars.length())));
        }
        return sb.toString();
    }
}
